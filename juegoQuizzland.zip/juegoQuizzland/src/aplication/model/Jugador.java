package aplication.model;

public class Jugador {

	
}
