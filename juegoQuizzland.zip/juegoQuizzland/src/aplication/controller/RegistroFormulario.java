package aplication.controller;

public class RegistroFormulario {

}
